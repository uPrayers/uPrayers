import PrayerForm from "@/components/PrayerForm";
export default function Page() {
  return <PrayerForm />;
}
